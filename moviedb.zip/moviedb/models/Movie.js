const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define the Genre schema
const genreSchema = new Schema({
    name: { type: String, required: true },
    description: { type: String },
});

// Define the Director schema
const directorSchema = new Schema({
    name: { type: String, required: true },
    bio: { type: String },
    birthYear: { type: Number },
    deathYear: { type: Number },
});

// Define the Movie schema
const movieSchema = new Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    genre: genreSchema,
    director: directorSchema,
    imageURL: { type: String },
    isFeatured: { type: Boolean, default: false },
});

// Create the Movie model
const Movie = mongoose.model("Movie", movieSchema);

module.exports = Movie;
